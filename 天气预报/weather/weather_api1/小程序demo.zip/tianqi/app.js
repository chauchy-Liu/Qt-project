// app.js
App({
  onLaunch() {
    // 展示本地存储能力
  },
  globalData: {
    /* 该账号appid为平台测试账号, 请购买正式接口 https://tianqiapi.com */
    apiurl:'https://v0.yiketianqi.com/',
    appid:'43656176',
    appsecret:'I42og6Lm'
  }
})

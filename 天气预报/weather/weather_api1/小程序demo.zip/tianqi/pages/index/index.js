// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    height: 0,
    background: 'https://xintai.xianguomall.com/skin/bg_sun.jpg',
    info: [],
    aircircle: 0, screenWidth: 0
  },
  onLoad() {
    var _this = this;
    wx.request({
      url: app.globalData.apiurl + 'api?unescape=1&version=v91&appid=' + app.globalData.appid + '&appsecret=' + app.globalData.appsecret + '&ext=hours&cityid=&city=',
      data: {
      },
      method: 'POST',
      success: function (res) {
        console.log(res.data);
        // success
        if (res.statusCode == 200) {
          console.log('ajax _ success');
          // 计算aqi位置
          var aqi = res.data.data[0].air / 300;
          var circle = (_this.data.screenWidth - 0) * aqi;
          // 计算背景图
          if (res.data.data[0].wea.match(RegExp(/晴/))) {
            var bg = 'https://xintai.xianguomall.com/skin/bg_sun.jpg';
          } else {
            var bg = 'https://xintai.xianguomall.com/skin/bg_yin.jpg';
          }
          // output
          _this.setData({
            background: bg,
            aircircle: circle,
            info: res.data
          });
          console.log('circle: ' + circle)
        }
      }
    })
  },
  onShow() {
    var _this = this;
    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        _this.setData({
          height: res.statusBarHeight,
          screenWidth: res.screenWidth
        });
      }
    })
  },/**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var _this = this;
    // 设置菜单中的转发按钮触发转发事件时的转发内容
    var shareObj = {
      title: '今日天气',        // 默认是小程序的名称(可以写slogan等)
      path: '/pages/index/index',        // 默认是当前页面，必须是以‘/’开头的完整路径
      imageUrl: '',     //自定义图片路径，可以是本地文件路径、代码包文件路径或者网络图片路径，支持PNG及JPG，不传入 imageUrl 则使用默认截图。显示图片长宽比是 5:4
      success: function (res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {
        }
      }
    };
    return shareObj;
  },
})
